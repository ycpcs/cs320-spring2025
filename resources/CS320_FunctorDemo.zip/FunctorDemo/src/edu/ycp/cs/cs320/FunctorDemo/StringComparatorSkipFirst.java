package edu.ycp.cs.cs320.FunctorDemo;

import java.util.Comparator;
import java.util.List;

public class StringComparatorSkipFirst implements Comparator<String> {

	private List<String> excludedWords;
	
	public StringComparatorSkipFirst(List<String> excluded) {
		excludedWords = excluded;
	}

	@Override
	public int compare(String s1, String s2) {
		String s1Suffix = removeLeadingWord(s1);
		String s2Suffix = removeLeadingWord(s2);
		
		return s1Suffix.toLowerCase().compareTo(s2Suffix.toLowerCase());
	}
	
	private String removeLeadingWord(String s) {
		// Remove leading excluded word
		for(String ew : excludedWords) {
			String ewSp = ew + " ";
			if (s.substring(0,ew.length()+1).toLowerCase().equals(ewSp.toLowerCase())) {
				return s.substring(ew.length()+1,s.length());
			}			
		}
		return s;
	}
	
}
